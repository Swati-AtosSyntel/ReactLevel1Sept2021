import React,{Component} from 'react';
class App1 extends React.Component{
    constructor(props){
        super(props);
        this.state={message:"React is Javascript Library"}
    }
    render(){
        const numbers=[1,2,3,45,67,78];
        const squareList=numbers.map((num)=><li>{num*num}</li>)
        return <div>
            <h1>Hello, {this.props.name} Welcome to React!!!!</h1>
            <h3>{this.state.message}</h3>
            <ul>
                {squareList}
            </ul>
        </div>
    }
}
App1.defaultProps={
    name:"User"
}
export default App1;