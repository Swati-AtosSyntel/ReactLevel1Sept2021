function UserLogin(props){
    return <h1>Welcome {props.name} back!!!</h1>;
}
function GuestLogin(props){
return <h4>Welcome GuestUser, Please signup for further access</h4>

}

function SignUp(props){
    const isloggedIn=props.isloggedIn;
    if(isloggedIn){
        return <UserLogin name="Swati"/>
    }
    return <GuestLogin/>;
}
export default SignUp;