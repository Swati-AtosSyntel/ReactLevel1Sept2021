
import React,{Component} from 'react';

class Employee extends React.Component{
    constructor(props){
        super(props);
        this.state={EmployeeId:345,ename:"Swati"}
    }
    render(){
        return(
            <div>
                <h4>Employee Details</h4>
                <DataTable id={this.state.EmployeeId} name={this.state.ename}/>
            </div>
        )
    }
}
export default Employee;
class DataTable extends React.Component{
    render(){
        return(
            <table border="1">
                <tr>
                    <th>Employee ID</th>
                    <th>Employee Name</th>

                </tr>
                <tr>
                    <td>{this.props.id}</td>
                    <td>{this.props.name}</td>
                </tr>

            </table>
        )
    }
}