import logo from './logo.svg';
import './App.css';
import Welcome from './Welcome';
import App1 from './App1';
import Employee from './Employee';
import Employee1 from './Employee1';
import App2 from './App2';
import SignUp from './SignUp';
import LoginControl from './LoginControl';
function App() {
  return (
    <div>
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
      {/* <Welcome name="Sneha"/>
      <Welcome name="Pradeep"/>
    <App1 name="Manisha"/>*/}
      {/* <App1/> 
      <Employee/>
      <hr/>
      <Employee1/> */}
      {/* <App2/> */}
      {/* <SignUp isloggedIn={false}/> */}
      <LoginControl/>
    </div>
  );
}

export default App;
