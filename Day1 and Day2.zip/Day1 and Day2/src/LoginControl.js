import React,{Component} from 'react';
import SignUp from './SignUp';

function LoginButton(props){
    return(
        <button onClick={props.onClick}> Login</button>
    );
}
function LogoutButton(props){
    return(
        <button onClick={props.onClick}> Logout</button>
    );
}

class LoginControl extends React.Component{
constructor(props){
    super(props);

this.state={isloggedIn:false};
this.handleLoginClick=this.handleLoginClick.bind(this);
this.handleLogoutClick=this.handleLogoutClick.bind(this);
    
}
handleLogoutClick(){
    
this.setState({isloggedIn:false})
}
handleLoginClick(){
 
    this.setState({isloggedIn:true})
}
render(){
    const isloggedIn=this.state.isloggedIn;
    let button;
    if(isloggedIn){
        button=<LogoutButton onClick={this.handleLogoutClick}/>;
    }
    else{
        button=<LoginButton onClick={this.handleLoginClick}/>;
    }
    return(
        <div>
            <SignUp isloggedIn={isloggedIn}/>
            {button}
        </div>
    )
}

}
export default LoginControl;