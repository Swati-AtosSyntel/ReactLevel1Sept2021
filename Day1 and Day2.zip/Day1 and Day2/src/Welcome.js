function Welcome(props){
    return(
        <div>
            <h3>Hello, Welcome to React</h3>
            <h2>hi,{props.name}</h2>
        </div>
    )
}

export default Welcome;