
import React,{Component} from 'react';

class Employee1 extends React.Component{
    constructor(){
        super();
        this.state={
            data:[
                {"EmployeeId":345,"ename":"Swati"},
                {"EmployeeId":346,"ename":"Manisha"},
                {"EmployeeId":347,"ename":"Giri"},
                {"EmployeeId":348,"ename":"Subbu"},
                {"EmployeeId":349,"ename":"Pradeep"}
            ]
        }
    }
    render(){
        return(
            <div>
                <h4>Employee Details</h4>
                <table border="1">
                <tr>
                    <th>Employee ID</th>
                    <th>Employee Name</th>

                </tr>
                <tbody>
                {this.state.data.map((emp)=>
                <TableRow employees={emp}/>)}
                </tbody>
                </table>
                
            </div>
        )
    }
}
export default Employee1;
class TableRow extends React.Component{
    render(){
        return(
            
                <tr>
                    <td>{this.props.employees.EmployeeId}</td>
                    <td>{this.props.employees.ename}</td>
                </tr>

          
        )
    }
}