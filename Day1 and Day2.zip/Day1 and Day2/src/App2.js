import React,{Component} from 'react';

class App2 extends React.Component{
    constructor(){
        super();
        this.state={num:0};
        this.setNewNum=this.setNewNum.bind(this);
    }
    setNewNum(){
        this.setState({num:this.state.num+2})
    }
    render(){
        return(
            <div>
            <button onClick={this.setNewNum}>Increment Number</button>
            {/* <h4>{this.state.num}</h4> */}
            <Data newNum={this.state.num}/>
            </div>
        );
    }
}
export default App2;
class Data extends React.Component{
    componentWillMount(){

        console.log('Component will mount')
    }
    componentDidMount(){
        console.log('Component Did mount')
    }
    componentWillReceiveProps(newProps){
        console.log('Component will receive prop');
    }
    shouldComponentUpdate(newProps,newState){
            return true;
        }
        componentWillUpdate(nextProps,nextState){
            console.log("Component Will Update");
        }
        render(){
            return(
                <div>
                    <h4>{this.props.newNum}</h4>
                </div>
            );
        }
    }
