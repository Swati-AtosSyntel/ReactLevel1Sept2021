import React,{Component} from 'react';

class ControlledForm extends  React.Component{
    constructor(){
        super();
        this.state={value:''};
this.onSubmitClick=this.onSubmitClick.bind(this);
this.updateState=this.updateState.bind(this);
    }
    updateState(event){
        this.setState({value:event.target.value});
    }
    onSubmitClick(event){
        alert(this.state.value);
        event.preventDefault();

    }
    render(){
        return(
            <form onSubmit={this.onSubmitClick}>
                <h4>Controlled Form</h4>
                <label>First Name:</label>
                <input type="text" value={this.state.value} onChange={this.updateState}/>
                
                <input type="Submit" value="Submit"/>
            </form>
        )
    }
}
export default ControlledForm;