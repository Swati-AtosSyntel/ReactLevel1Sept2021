import React,{useState} from 'react';

function CountApp(){
     const[count,setCount]=useState(0);
     const[message,setMessage]=useState("This is my text");
     return(
         <div>
             <p>You clicked {count} times</p>
             <button onClick={()=>setCount(count+1)}>Click Me</button>
             <p>{message}</p>
             <button onClick={()=>setMessage("Welcome to React Hooks")}>Update Message</button>
         </div>
     )
}
export default CountApp;