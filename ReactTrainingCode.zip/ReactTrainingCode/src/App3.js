import React,{Component} from 'react';

class App3 extends React.Component{
    constructor(props){
        super(props);
        this.state={num:0};
        this.setNewNum=this.setNewNum.bind(this);
    }
    setNewNum(){
        this.setState({num:this.state.num+2})
    }
    render(){
        return(
            <div>
           
           <Content updateStateProp={this.setNewNum} newNum={this.state.num}/>
            </div>
        );
    }
}
export default App3;
class Content extends React.Component{
    render(){
        return(
            <div>
                <button onClick={this.props.updateStateProp}>Update State</button>
                <h4>{this.props.newNum}</h4>
            </div>
        )
    }
}