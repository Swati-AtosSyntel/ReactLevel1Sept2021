import React,{useContext} from 'react';
import authContext from './auth';

const Auth=()=>{
    const auth=useContext(authContext);
    console.log(auth.status);
    return(
        <div>
            <h1>Valid User?</h1>
            {auth.status?<p>Valid User!!!</p>:<p>Invalid Use</p>}
            <button onClick={auth.login}>Click here to Login</button>
        </div>
    );
}
export default Auth;
