import React,{Component} from 'react';

class UnControlledForm extends React.Component{
    constructor(props){
        super(props);
        this.onSubmitClick=this.onSubmitClick.bind(this);
        this.input=React.createRef();
    }
    onSubmitClick(event){
        alert('you have entered username and companyname successfully');
        event.preventDefault();
    }
    render(){
        return(
            <form onSubmit={this.onSubmitClick}>
                <h4>UnControlled Form</h4>
                <label>First Name:</label>
                <input type="text" ref={this.input}/>
                <label>Email ID:</label>
                <input type="text" ref={this.input} />
                <input type="Submit" value="Submit"/>
            </form>
        )
    }
}
export default UnControlledForm;