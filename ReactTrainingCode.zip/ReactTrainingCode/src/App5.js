import React,{useState} from 'react';

import Auth from './ContextHook';

import authContext from './auth';

const App5=()=>{
    const [authStatus,setauthstatus]=useState(false);

    const login=()=>{
        setauthstatus(true);
    };
    return (
        <div>
            <authContext.Provider value={{status:authStatus,login:login}}>
                <Auth/>
            </authContext.Provider>
        </div>
    )
}
export default App5;